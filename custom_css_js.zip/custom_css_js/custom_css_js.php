<?php
 
/*
 
Plugin Name: Adding custom css and js 
  
Description: Plugin to add the custom css and js to modify the home page to home page
 
Version: 1.0
 
Author: Pavithra N
 
 
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

add_action( 'wp_footer', 'my_custom_script_load' );
function my_custom_script_load(){
	if( is_home() || is_front_page() ) {
		wp_enqueue_script( 'my-custom-script', plugin_dir_url( __FILE__ ) . 'custom.js', array( 'jquery' ) );
		wp_enqueue_style( 'my-custom-script', plugin_dir_url( __FILE__ ) . 'custom.css');
	}

}

?>